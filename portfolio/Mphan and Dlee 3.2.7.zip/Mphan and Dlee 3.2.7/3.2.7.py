
from scipy import stats
import matplotlib.pyplot as plt
import numpy as np
import os.path
from matplotlib.offsetbox import AnchoredText
# A generic helper function for matplotlib.pyplot graphics
def make_PLTW_style(axes):
    for item in ([axes.title, axes.xaxis.label, axes.yaxis.label] +
             axes.get_xticklabels() + axes.get_yticklabels()):
        item.set_family('Georgia')
        item.set_fontsize(16)

###
# Get the income/age data from CSV
###
# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))
# Build an absolute filename from directory + filename
filename = os.path.join(directory, '3.2.7.csv')
datafile = open(filename,'r')
data = datafile.readlines()

####
# Transform the data from strings to signed integers
####

gdps=[]
snumber=[]
n=50
for line in data[3:]: # Omit 0, 1, 2 because _______
    country, gdp, rate = line.split(',')

    # ___________ the age data
    snumber.append(float(rate))
    gdps.append(float(gdp))


fig_age, ax  = plt.subplots(1, 1)
ax.plot(snumber, np.poly1d(np.polyfit(snumber,gdps, 1))(snumber), color = "blue") #makes the regression line
slope, intercept, r_value, p_value, std_err = stats.linregress(snumber,gdps) #imports "stat" with its .linregress() method library. It will calculate the slope, intercept, rvalue, pvalue, standard error. 
r2_value = r_value**2 #determines the coefficient of determination
y = str(intercept) + '+' + str(slope) + 'x'#this creates the linear regression equation
key = '\nKey' '\nR-value: ' + str(r_value)+ '\n R-squared value: ' + str(r2_value) + '\n P-value: ' + str(p_value) + '\n Linear Regression: y  = ' + y #organizes all data line by line so that each "item" (ie: r2_value) is properlly spaced.

summary ='\nSummary' '\nThere is a very weak positive linear association between the GDP of a particular country and the suicide rate of that particular country. Also, since the R-squared value is 0.01965, about 1.9% of the variation in suicide rate can be explained by our model.' #the interpretation and conclusion of our data

ax.scatter(gdps, snumber, color='green') #formats the scatterplot
ax.set_title('GDP VS Rate of Suicides') #the title of scatterplot
ax.set_xlabel('GDP per country') #the label of the scatterplot in the x axis
ax.set_ylabel('Rate of Suicides per country') #the label of the scatterplot in the y axis
fig_age.show()
plt.annotate(key, xy=(0.20, 0.50), xycoords='axes fraction')
#main
print(key)
print(summary)